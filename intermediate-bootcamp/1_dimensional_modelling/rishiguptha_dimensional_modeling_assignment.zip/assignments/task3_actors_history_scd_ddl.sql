-- TASK - 3
DROP TABLE actors_history_scd;  
CREATE TABLE actors_history_scd(
    actorid TEXT,
    actor TEXT,
    quality_class quality_class,
    is_active BOOLEAN,
    start_year INTEGER,
    end_year INTEGER,
    current_year INTEGER, -- Snapshot stamp for which yearly SCD state this row belongs to
    PRIMARY KEY(actorid, start_year)
);